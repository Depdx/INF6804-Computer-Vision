[Lien vers le rapport](https://1drv.ms/w/s!Anleb4SYy5OrmED5EvMixahjRFiz?e=a6xOaX)
[Lien vers wandb](https://wandb.ai/depdx/computer-vision-tp3?workspace=user-nicolasdepelteau)

# Resources

